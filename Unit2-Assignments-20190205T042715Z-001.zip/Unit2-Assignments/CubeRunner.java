//(c) A+ Computer Science
//www.apluscompsci.com
//Name -
//Date -

public class CubeRunner
{
	public static void main( String[] args )
   {
		System.out.println( "Cube area is :: " + Cube.area( 112 ) );
		System.out.println( "Cube area is :: " + Cube.area( 4 ) );
		System.out.println( "Cube area is :: " + Cube.area( 33 ) );
		System.out.println( "Cube area is :: " + Cube.area( 50 ) );
		System.out.println( "Cube area is :: " + Cube.area( 5 ) );		
		System.out.println( "Cube area is :: " + Cube.area( 19 ) );
		System.out.println( "Cube area is :: " + Cube.area( 111 ) );

	}
}




