//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class -
//Lab  - 

public class Trap
{
	public static double area( int base1, int base2, int height )
	{
		return 0;
	}
}