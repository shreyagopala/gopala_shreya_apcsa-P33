//(c) A+ Computer Science
// www.apluscompsci.com
//Name -
//Date -

public class Cube
{
	public static double area( int side )
	{
		return 0;
	}
}